import React from "react";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";

import "./FeedbackList.css";

import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import ScoreIcon from "./ScoreIcon";

export default function FeedbackList({ feedbackList = [] }) {
  console.log(feedbackList);
  return (
    <List>
      {feedbackList.map(feedback => {
        return (
          <ListItem key={feedback.id}>
            <ListItemAvatar>
              <ScoreIcon score={feedback.score} />
            </ListItemAvatar>
            <ListItemText
              primary={feedback.name}
              secondary="informacinis tekstas"
            />
          </ListItem>
        );
      })}
    </List>
  );
}
